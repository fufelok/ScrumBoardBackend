package se.leanbit.ticketsystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import se.leanbit.ticketsystem.model.User;
import se.leanbit.ticketsystem.repository.UserRepository;

public class UserService
{
    @Autowired
    private UserRepository userRepository;

    public void addUser(final User user)
    {
        userRepository.save(user);
    }

    public void removeUser(final String userID)
    {
        userRepository.removeByID(userID);
    }
}
