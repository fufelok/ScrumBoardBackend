package se.leanbit.ticketsystem.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import se.leanbit.ticketsystem.service.UserService;

@Configuration
public class ServiceConfig
{

	@Bean
	public UserService userService()
	{
		return new UserService();
	}

}
