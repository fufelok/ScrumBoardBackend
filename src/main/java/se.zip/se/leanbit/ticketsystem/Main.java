package se.leanbit.ticketsystem;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import se.leanbit.ticketsystem.model.Team;
import se.leanbit.ticketsystem.model.User;
import se.leanbit.ticketsystem.model.WorkItem;
import se.leanbit.ticketsystem.repository.TeamRepository;
import se.leanbit.ticketsystem.repository.WorkItemRepository;
import se.leanbit.ticketsystem.service.UserService;

import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext())
        {
            context.scan("se.leanbit.ticketsystem.config");
            context.refresh();

            UserService us = context.getBean(UserService.class);
            TeamRepository tr = context.getBean(TeamRepository.class);
            WorkItemRepository wr = context.getBean(WorkItemRepository.class);

            Team team = new Team("Leanbit");
            User user1 = new User("920406", "Kira", "Erik", "Welander", "Elfen", team);
            User user2 = new User("920406222", "Kira2", "Erik2", "Welander2", "Elfen2", team);

            team.addTeamMember(user1);
            team.addTeamMember(user2);

            tr.save(team);

            //tr.getUsersByTeamName("leanbit").forEach(System.out::println);

            WorkItem wi = new WorkItem("Fixdisshit", "BLAH", "DO_IT", 9001);
            WorkItem wi2 = new WorkItem("Fixdisshit22", "BLAH222", "DO_IT222", 9001222);

            wr.save(wi);
            wr.save(wi2);


            team.addWorkItem(wi);
            team.addWorkItem(wi2);

            tr.save(team);

            us.removeUser(user2.getUserID());

        }

    }
}
