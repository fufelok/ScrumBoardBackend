package se.leanbit.ticketsystem.repository;
import org.springframework.data.jpa.repository.Query;
import se.leanbit.ticketsystem.model.Team;
import org.springframework.data.repository.CrudRepository;
import se.leanbit.ticketsystem.model.User;

import java.util.List;

public interface TeamRepository extends CrudRepository<Team, Long>
{
    @Query("select u from User u where u.team.teamName = ?1")
    List<User> getUsersByTeamName(final String teamName);
}