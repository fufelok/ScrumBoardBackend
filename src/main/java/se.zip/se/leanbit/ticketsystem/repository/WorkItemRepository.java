package se.leanbit.ticketsystem.repository;
import org.springframework.data.jpa.repository.Query;
import se.leanbit.ticketsystem.model.Team;
import org.springframework.data.repository.CrudRepository;
import se.leanbit.ticketsystem.model.User;
import se.leanbit.ticketsystem.model.WorkItem;

import java.util.List;

public interface WorkItemRepository extends CrudRepository<WorkItem, Long>
{

}